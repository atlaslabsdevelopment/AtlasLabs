import {useEffect, useRef} from 'react';
import gsap from 'gsap';
import {ArrowUpRight} from 'lucide-react';
import {EXTERNAL_LINKS} from '../lib/assets';
import type {AppRoute} from '../lib/router';
import {AtlasOSShowcase} from '../components/AtlasOSShowcase';

interface AtlasOSPageProps {
  onNavigate: (route: AppRoute) => void;
}

const DESIGN_NOTES = [
  {
    title: 'Familiarity over novelty',
    body: 'Windows, preferences, and spatial anchors follow clear, predictable patterns so nothing requires relearning.',
  },
  {
    title: 'Tactile materials',
    body: 'Frosted surfaces, subtle depth, and calm contrast help active windows feel grounded against the desktop.',
  },
  {
    title: 'Quiet by default',
    body: 'The workspace keeps visual clutter out of view, leaving room for your work and the environment around it.',
  },
];

export function AtlasOSPage({onNavigate}: AtlasOSPageProps) {
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window === 'undefined' || !rootRef.current) {
      return;
    }
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion) {
      return;
    }

    const ctx = gsap.context(() => {
      gsap.from('.atlasos-header', {
        opacity: 0,
        y: 18,
        duration: 0.65,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
      });
      gsap.from('.atlasos-stage', {
        opacity: 0,
        y: 22,
        duration: 0.75,
        delay: 0.12,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
      });
    }, rootRef);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={rootRef}>
      {/* Page Header */}
      <section className="mx-auto max-w-6xl px-6 pt-14 pb-10 sm:pt-20 sm:pb-12 lg:px-8">
        <div className="atlasos-header max-w-3xl">
          <p className="text-[13px] font-medium text-[#767982]">
            AtlasOS · In active development · Not yet released
          </p>
          <h1 className="mt-3 font-display text-[clamp(2.25rem,4.2vw,3.5rem)] font-semibold tracking-[-0.03em] leading-[1.08] text-[#111214] text-balance">
            An operating system shaped around calm, everyday enjoyment.
          </h1>
          <p className="mt-5 max-w-2xl text-[16px] sm:text-[17px] leading-[1.65] text-[#52545C]">
            AtlasOS is an independent desktop operating system currently being built at
            Atlas Labs. It is not available for download yet. Below are authentic
            interface previews from active development.
          </p>
        </div>
      </section>

      {/* Authentic Interactive Showcase */}
      <section className="studio-surface border-y border-black/[0.06]">
        <div className="atlasos-stage mx-auto max-w-6xl px-6 py-12 sm:py-16 lg:px-8">
          <AtlasOSShowcase enableAnnotations />
        </div>
      </section>

      {/* Design Principles & Progress Channels */}
      <section className="mx-auto max-w-6xl px-6 py-16 sm:py-20 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          {DESIGN_NOTES.map((note) => (
            <div
              key={note.title}
              className="border-t border-black/[0.08] pt-6"
            >
              <h2 className="font-display text-[17px] font-semibold tracking-[-0.015em] text-[#111214]">
                {note.title}
              </h2>
              <p className="mt-2.5 text-[15px] leading-[1.65] text-[#52545C]">
                {note.body}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-14 rounded-2xl border border-black/[0.08] bg-[#F6F6F8] p-7 sm:p-9 flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="font-display text-[18px] font-semibold tracking-[-0.015em] text-[#111214]">
              Development updates
            </h2>
            <p className="mt-1.5 max-w-xl text-[15px] leading-relaxed text-[#52545C]">
              AtlasOS is still in early development with no public release date yet.
              Progress is shared directly on YouTube and GitHub.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <a
              href={EXTERNAL_LINKS.youtube}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-[44px] items-center gap-1.5 rounded-full bg-[#111214] px-5 py-2.5 text-[14px] font-medium text-white whitespace-nowrap transition-colors hover:bg-[#2A2C30]"
            >
              <span>YouTube</span>
              <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
            </a>
            <button
              type="button"
              onClick={() => onNavigate('/about')}
              className="inline-flex min-h-[44px] items-center rounded-full border border-black/[0.12] bg-white px-5 py-2.5 text-[14px] font-medium text-[#111214] whitespace-nowrap transition-colors hover:bg-neutral-50"
            >
              About Atlas Labs
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
