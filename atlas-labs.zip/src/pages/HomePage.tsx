import {useEffect, useRef} from 'react';
import gsap from 'gsap';
import {ScrollTrigger} from 'gsap/ScrollTrigger';
import {ArrowRight, ArrowUpRight} from 'lucide-react';
import {BRAND_ASSETS, EXTERNAL_LINKS} from '../lib/assets';
import type {AppRoute} from '../lib/router';
import {AtlasOSShowcase} from '../components/AtlasOSShowcase';
import {OptimizedImage} from '../components/OptimizedImage';

gsap.registerPlugin(ScrollTrigger);

interface HomePageProps {
  onNavigate: (route: AppRoute) => void;
}

export function HomePage({onNavigate}: HomePageProps) {
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window === 'undefined' || !rootRef.current) {
      return;
    }
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion) {
      return;
    }

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({defaults: {ease: 'power3.out'}});

      tl.from('.hero-mark', {
        opacity: 0,
        scale: 0.9,
        y: 12,
        duration: 0.75,
        clearProps: 'transform,opacity',
      })
        .from(
          '.hero-title',
          {
            opacity: 0,
            y: 18,
            duration: 0.65,
            clearProps: 'transform,opacity',
          },
          '-=0.45'
        )
        .from(
          '.hero-slogan',
          {
            opacity: 0,
            y: 16,
            duration: 0.65,
            clearProps: 'transform,opacity',
          },
          '-=0.48'
        )
        .from(
          '.hero-lead',
          {
            opacity: 0,
            y: 14,
            duration: 0.6,
            clearProps: 'transform,opacity',
          },
          '-=0.45'
        )
        .from(
          '.hero-actions',
          {
            opacity: 0,
            y: 12,
            duration: 0.55,
            clearProps: 'transform,opacity',
          },
          '-=0.42'
        );

      gsap.from('.showcase-stage', {
        opacity: 0,
        y: 28,
        duration: 0.85,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
        scrollTrigger: {
          trigger: '.showcase-stage',
          start: 'top 86%',
          once: true,
        },
      });

      gsap.from('.philosophy-band', {
        opacity: 0,
        y: 22,
        duration: 0.75,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
        scrollTrigger: {
          trigger: '.philosophy-band',
          start: 'top 88%',
          once: true,
        },
      });
    }, rootRef);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={rootRef}>
      {/* Band 1: Hero & Official Identity */}
      <section className="mx-auto max-w-6xl px-6 pt-16 pb-14 sm:pt-24 sm:pb-20 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <div className="hero-mark mb-7 flex justify-center">
            <div className="inline-flex h-16 w-16 sm:h-[72px] sm:w-[72px] items-center justify-center rounded-2xl bg-[#F6F6F8] p-3 ring-1 ring-black/[0.06]">
              <OptimizedImage
                asset={BRAND_ASSETS.mark}
                loading="eager"
                fetchPriority="high"
                imgClassName="h-full w-full object-contain select-none"
              />
            </div>
          </div>

          <h1 className="hero-title font-display text-[clamp(2.5rem,5vw,4.25rem)] font-semibold tracking-[-0.035em] leading-[1.05] text-[#111214] text-balance">
            Atlas Labs
          </h1>

          <p className="hero-slogan mt-2.5 font-display text-[clamp(1.75rem,3.4vw,2.75rem)] font-medium tracking-[-0.028em] leading-[1.12] text-[#52545C]">
            Made Enjoyable
          </p>

          <p className="hero-lead mx-auto mt-6 max-w-xl text-[16px] sm:text-[17px] leading-[1.65] text-[#52545C]">
            An independent technology company designing personal software with warmth,
            clarity, and care.
          </p>

          <div className="hero-actions mt-9 flex flex-wrap items-center justify-center gap-4">
            <button
              type="button"
              onClick={() => onNavigate('/atlasos')}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-full bg-[#111214] px-6 py-2.5 text-[14px] font-medium text-white whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[#2A2C30]"
            >
              <span>Explore AtlasOS</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={() => onNavigate('/about')}
              className="inline-flex min-h-[44px] items-center rounded-full border border-black/[0.12] bg-white px-6 py-2.5 text-[14px] font-medium text-[#111214] whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[#F6F6F8]"
            >
              About Atlas Labs
            </button>
          </div>
        </div>
      </section>

      {/* Band 2: Art-Directed AtlasOS Product Showcase */}
      <section
        aria-label="AtlasOS preview"
        className="studio-surface border-y border-black/[0.06]"
      >
        <div className="showcase-stage mx-auto max-w-6xl px-6 py-14 sm:py-20 lg:px-8">
          <div className="mb-8 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-[13px] font-medium text-[#767982]">
                AtlasOS · Early development preview
              </p>
              <h2 className="mt-1 font-display text-[24px] sm:text-[28px] font-semibold tracking-[-0.02em] text-[#111214]">
                Personal computing, quietly refined
              </h2>
            </div>
          </div>

          <AtlasOSShowcase onLearnMore={() => onNavigate('/atlasos')} />
        </div>
      </section>

      {/* Band 3: Concise Craft Statement & Official Channels */}
      <section className="mx-auto max-w-6xl px-6 py-16 sm:py-24 lg:px-8">
        <div className="philosophy-band grid grid-cols-1 gap-10 md:grid-cols-12 md:items-start">
          <div className="md:col-span-7">
            <h2 className="font-display text-[24px] sm:text-[30px] font-semibold tracking-[-0.022em] leading-[1.2] text-[#111214] text-balance">
              Built for people who still appreciate well-made software.
            </h2>
            <p className="mt-4 max-w-xl text-[16px] leading-[1.68] text-[#52545C]">
              Rather than chasing visual noise or sterile complexity, Atlas Labs focuses
              on familiar proportions, thoughtful materials, and interfaces that feel
              genuinely pleasant to spend time in.
            </p>
          </div>

          <div className="md:col-span-5 md:border-l md:border-black/[0.08] md:pl-10 flex flex-col gap-5">
            <div>
              <p className="text-[13px] font-medium text-[#767982]">
                Follow our work
              </p>
              <div className="mt-3 flex flex-col items-start gap-2.5">
                <a
                  href={EXTERNAL_LINKS.youtube}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-[40px] items-center gap-1.5 text-[15px] font-medium text-[#111214] hover:text-[#52545C] transition-colors"
                >
                  <span>YouTube — @AtlasLabsDevelopment</span>
                  <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                </a>
                <a
                  href={EXTERNAL_LINKS.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-[40px] items-center gap-1.5 text-[15px] font-medium text-[#111214] hover:text-[#52545C] transition-colors"
                >
                  <span>GitHub — atlaslabsdevelopment</span>
                  <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                </a>
                <button
                  type="button"
                  onClick={() => onNavigate('/about')}
                  className="inline-flex min-h-[40px] items-center gap-1.5 text-[15px] font-medium text-[#52545C] hover:text-[#111214] transition-colors"
                >
                  <span>Get in touch</span>
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
