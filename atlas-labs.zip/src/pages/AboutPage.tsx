import {useEffect, useRef, useState} from 'react';
import gsap from 'gsap';
import {ArrowUpRight, Check, Copy, Mail} from 'lucide-react';
import {BRAND_ASSETS, EXTERNAL_LINKS} from '../lib/assets';
import {OptimizedImage} from '../components/OptimizedImage';

export function AboutPage() {
  const rootRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined' || !rootRef.current) {
      return;
    }
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion) {
      return;
    }

    const ctx = gsap.context(() => {
      gsap.from('.about-reveal', {
        opacity: 0,
        y: 18,
        duration: 0.65,
        stagger: 0.08,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
      });
    }, rootRef);

    return () => ctx.revert();
  }, []);

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText(EXTERNAL_LINKS.email);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      window.location.href = `mailto:${EXTERNAL_LINKS.email}`;
    }
  };

  return (
    <div ref={rootRef} className="mx-auto max-w-6xl px-6 py-14 sm:py-20 lg:px-8">
      {/* Header */}
      <div className="about-reveal max-w-3xl">
        <p className="text-[13px] font-medium text-[#767982]">
          About · Atlas Labs
        </p>
        <h1 className="mt-3 font-display text-[clamp(2.25rem,4.2vw,3.5rem)] font-semibold tracking-[-0.03em] leading-[1.08] text-[#111214] text-balance">
          Making personal computing enjoyable again.
        </h1>
      </div>

      {/* Main Content Split */}
      <div className="mt-12 grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16">
        <div className="about-reveal lg:col-span-7 space-y-6 text-[16px] sm:text-[17px] leading-[1.7] text-[#52545C]">
          <p className="text-[#111214] font-medium">
            Atlas Labs is an independent technology development effort focused on
            thoughtful personal software.
          </p>
          <p>
            Over the past decade, everyday computing has grown louder, busier, and more
            utilitarian. Interfaces feel assembled for metrics rather than people. Atlas
            Labs exists because we miss software that feels cohesive, attentive, and
            genuinely pleasant to open every day.
          </p>
          <p>
            Our work draws inspiration from the clarity and warmth of classic desktop
            computing—careful proportions, subtle material depth, legible typography, and
            interactions that feel responsive without demanding attention. We value
            craftsmanship over trends and simplicity over unnecessary complexity.
          </p>
          <p>
            Right now, our primary focus is AtlasOS, an independent operating system in
            active development. We share progress openly as the work takes shape.
          </p>
        </div>

        {/* Brand & Contact Column */}
        <aside className="about-reveal lg:col-span-5">
          <div className="rounded-2xl border border-black/[0.08] bg-[#F6F6F8] p-7 sm:p-8">
            <div className="pb-6 border-b border-black/[0.08]">
              <OptimizedImage
                asset={BRAND_ASSETS.lockup}
                loading="eager"
                imgClassName="h-8 w-auto object-contain"
              />
              <p className="mt-2.5 text-[14px] text-[#52545C]">
                Made Enjoyable
              </p>
            </div>

            <div className="mt-6 space-y-6">
              <div>
                <h2 className="text-[12px] font-medium text-[#767982]">
                  Contact
                </h2>
                <div className="mt-2 flex flex-col gap-2.5">
                  <a
                    href={`mailto:${EXTERNAL_LINKS.email}`}
                    className="inline-flex items-center gap-2 text-[15px] font-medium text-[#111214] hover:text-[#52545C] transition-colors break-all"
                  >
                    <Mail className="h-4 w-4 shrink-0 text-[#52545C]" aria-hidden="true" />
                    <span>{EXTERNAL_LINKS.email}</span>
                  </a>
                  <div>
                    <button
                      type="button"
                      onClick={handleCopyEmail}
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-black/[0.1] bg-white px-3 py-1.5 text-[13px] font-medium text-[#111214] transition-colors hover:bg-neutral-50"
                    >
                      {copied ? (
                        <>
                          <Check className="h-3.5 w-3.5 text-[#111214]" aria-hidden="true" />
                          <span>Email copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5 text-[#52545C]" aria-hidden="true" />
                          <span>Copy email address</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              <div className="pt-5 border-t border-black/[0.08]">
                <h2 className="text-[12px] font-medium text-[#767982]">
                  Official channels
                </h2>
                <div className="mt-3 flex flex-col gap-2">
                  <a
                    href={EXTERNAL_LINKS.youtube}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[42px] items-center justify-between rounded-xl border border-black/[0.08] bg-white px-4 py-2.5 text-[14px] font-medium text-[#111214] transition-colors hover:border-black/20"
                  >
                    <span>YouTube</span>
                    <ArrowUpRight className="h-4 w-4 text-[#52545C]" aria-hidden="true" />
                  </a>
                  <a
                    href={EXTERNAL_LINKS.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[42px] items-center justify-between rounded-xl border border-black/[0.08] bg-white px-4 py-2.5 text-[14px] font-medium text-[#111214] transition-colors hover:border-black/20"
                  >
                    <span>GitHub</span>
                    <ArrowUpRight className="h-4 w-4 text-[#52545C]" aria-hidden="true" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
