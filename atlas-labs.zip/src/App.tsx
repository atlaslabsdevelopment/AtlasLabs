import {useEffect, useRef} from 'react';
import gsap from 'gsap';
import {ScrollTrigger} from 'gsap/ScrollTrigger';
import Lenis from 'lenis';
import {Footer} from './components/Footer';
import {Navbar} from './components/Navbar';
import {useHashRouter, type AppRoute} from './lib/router';
import {AboutPage} from './pages/AboutPage';
import {AtlasOSPage} from './pages/AtlasOSPage';
import {HomePage} from './pages/HomePage';

gsap.registerPlugin(ScrollTrigger);

export default function App() {
  const {route, navigate} = useHashRouter();
  const lenisRef = useRef<Lenis | null>(null);
  const mainRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion) {
      return;
    }

    const lenis = new Lenis({
      duration: 1.05,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
    });
    lenisRef.current = lenis;

    lenis.on('scroll', ScrollTrigger.update);

    const tick = (time: number) => {
      lenis.raf(time * 1000);
    };
    gsap.ticker.add(tick);
    gsap.ticker.lagSmoothing(0);

    return () => {
      gsap.ticker.remove(tick);
      lenis.destroy();
      lenisRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (lenisRef.current) {
      lenisRef.current.scrollTo(0, {immediate: true});
    } else {
      window.scrollTo(0, 0);
    }
    ScrollTrigger.refresh();
  }, [route]);

  const handleNavigate = (target: AppRoute) => {
    if (target === route) {
      if (lenisRef.current) {
        lenisRef.current.scrollTo(0);
      } else {
        window.scrollTo({top: 0, behavior: 'smooth'});
      }
      return;
    }
    navigate(target);
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-[#111214]">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-50 focus:rounded-lg focus:bg-[#111214] focus:px-4 focus:py-2 focus:text-sm focus:font-medium focus:text-white"
      >
        Skip to content
      </a>

      <Navbar route={route} onNavigate={handleNavigate} />

      <main id="main-content" ref={mainRef} className="flex-1">
        {route === '/' && <HomePage onNavigate={handleNavigate} />}
        {route === '/atlasos' && <AtlasOSPage onNavigate={handleNavigate} />}
        {route === '/about' && <AboutPage />}
      </main>

      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
