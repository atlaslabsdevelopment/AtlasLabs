import {useCallback, useEffect, useState} from 'react';

export type AppRoute = '/' | '/atlasos' | '/about';

function normalizeHashToRoute(rawHash: string): AppRoute {
  const cleaned = rawHash.replace(/^#/, '').replace(/\/+$/, '') || '/';
  const lower = cleaned.toLowerCase();
  if (lower === '/atlasos' || lower === 'atlasos') {
    return '/atlasos';
  }
  if (lower === '/about' || lower === 'about') {
    return '/about';
  }
  return '/';
}

function getInitialRoute(): AppRoute {
  if (typeof window === 'undefined') {
    return '/';
  }
  if (window.location.hash) {
    return normalizeHashToRoute(window.location.hash);
  }
  const path = window.location.pathname.toLowerCase();
  if (path.endsWith('/atlasos') || path.endsWith('/atlasos/')) {
    return '/atlasos';
  }
  if (path.endsWith('/about') || path.endsWith('/about/')) {
    return '/about';
  }
  return '/';
}

const ROUTE_TITLES: Record<AppRoute, string> = {
  '/': 'Atlas Labs — Made Enjoyable',
  '/atlasos': 'AtlasOS — Atlas Labs',
  '/about': 'About — Atlas Labs',
};

export function useHashRouter() {
  const [route, setRoute] = useState<AppRoute>(getInitialRoute);

  useEffect(() => {
    const syncFromHash = () => {
      const next = normalizeHashToRoute(window.location.hash);
      setRoute(next);
    };

    if (!window.location.hash) {
      const initial = getInitialRoute();
      window.history.replaceState(null, '', `#${initial}`);
    }

    window.addEventListener('hashchange', syncFromHash);
    return () => window.removeEventListener('hashchange', syncFromHash);
  }, []);

  useEffect(() => {
    document.title = ROUTE_TITLES[route];
  }, [route]);

  const navigate = useCallback((target: AppRoute) => {
    const normalized = target === '/' ? '/' : target;
    if (window.location.hash !== `#${normalized}`) {
      window.location.hash = `#${normalized}`;
    } else {
      setRoute(normalized);
    }
  }, []);

  return {route, navigate};
}
