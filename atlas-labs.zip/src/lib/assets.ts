export interface MediaAsset {
  webp: string;
  fallback: string;
  width: number;
  height: number;
  alt: string;
}

export function resolveAssetUrl(relativePath: string): string {
  const base = import.meta.env.BASE_URL || '/';
  const normalizedBase = base.endsWith('/') ? base : `${base}/`;
  const cleanRelative = relativePath.startsWith('/') ? relativePath.slice(1) : relativePath;
  return `${normalizedBase}${cleanRelative}`;
}

export const BRAND_ASSETS = {
  mark: {
    webp: resolveAssetUrl('assets/images/atlas-mark.webp'),
    fallback: resolveAssetUrl('assets/images/atlas-mark.png'),
    width: 640,
    height: 640,
    alt: 'Atlas Labs mark',
  },
  lockup: {
    webp: resolveAssetUrl('assets/images/atlas-lockup.webp'),
    fallback: resolveAssetUrl('assets/images/atlas-lockup.png'),
    width: 2170,
    height: 725,
    alt: 'Atlas Labs',
  },
} satisfies Record<string, MediaAsset>;

export const ATLAS_OS_SCREENS = {
  desktop: {
    id: 'desktop',
    label: 'Desktop Workspace',
    caption: 'Calm desktop composition with a floating dock, centered workspace bar, and quiet system time.',
    webp: resolveAssetUrl('assets/images/atlasos-desktop.webp'),
    fallback: resolveAssetUrl('assets/images/atlasos-desktop.jpg'),
    width: 2400,
    height: 1561,
    alt: 'AtlasOS desktop environment showing the top workspace bar, scenic mountain lake wallpaper, centered floating dock, and bottom-right time indicator.',
  },
  appearance: {
    id: 'appearance',
    label: 'Appearance Preferences',
    caption: 'Appearance settings window with live workspace preview, frosted material toggles, and day or night surfaces.',
    webp: resolveAssetUrl('assets/images/atlasos-settings.webp'),
    fallback: resolveAssetUrl('assets/images/atlasos-settings.jpg'),
    width: 2400,
    height: 1561,
    alt: 'AtlasOS Settings window open to Appearance preferences with live preview, Light and Dark mode selector, frosted materials toggle, title font selector, and Day or Night system style.',
  },
} as const;

export type AtlasOSScreenKey = keyof typeof ATLAS_OS_SCREENS;

export const EXTERNAL_LINKS = {
  github: 'https://github.com/atlaslabsdevelopment',
  youtube: 'https://www.youtube.com/@AtlasLabsDevelopment',
  email: 'atlaslabsdevelopment@gmail.com',
  website: 'https://atlaslabsdevelopment.github.io/AtlasLabs/',
} as const;
