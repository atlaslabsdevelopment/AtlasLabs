import {useEffect, useState} from 'react';
import {ArrowUpRight, Menu, X} from 'lucide-react';
import {BRAND_ASSETS, EXTERNAL_LINKS} from '../lib/assets';
import type {AppRoute} from '../lib/router';
import {OptimizedImage} from './OptimizedImage';

interface NavbarProps {
  route: AppRoute;
  onNavigate: (route: AppRoute) => void;
}

const NAV_ITEMS: {label: string; route: AppRoute}[] = [
  {label: 'Home', route: '/'},
  {label: 'AtlasOS', route: '/atlasos'},
  {label: 'About', route: '/about'},
];

export function Navbar({route, onNavigate}: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 12);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, {passive: true});
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleLinkClick = (target: AppRoute) => {
    setMobileOpen(false);
    onNavigate(target);
  };

  return (
    <header
      className={`sticky top-0 z-40 transition-[background-color,border-color] duration-200 ${
        scrolled
          ? 'bg-white/80 backdrop-blur-xl border-b border-black/[0.08]'
          : 'bg-white/65 backdrop-blur-md border-b border-transparent'
      }`}
    >
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-8 px-6 lg:px-8">
        {/* Zone 1: Brand Lockup */}
        <a
          href="#/"
          onClick={(e) => {
            e.preventDefault();
            handleLinkClick('/');
          }}
          aria-label="Atlas Labs Home"
          className="flex items-center whitespace-nowrap shrink-0 py-1.5 rounded-md transition-opacity duration-150 hover:opacity-75"
        >
          <OptimizedImage
            asset={BRAND_ASSETS.lockup}
            loading="eager"
            fetchPriority="high"
            imgClassName="h-[26px] w-auto object-contain select-none"
          />
        </a>

        {/* Zone 2: Primary Navigation Links */}
        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-8"
        >
          {NAV_ITEMS.map((item) => {
            const isActive = route === item.route;
            return (
              <a
                key={item.route}
                href={`#${item.route}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleLinkClick(item.route);
                }}
                aria-current={isActive ? 'page' : undefined}
                className={`relative py-2 text-[14px] font-medium whitespace-nowrap shrink-0 transition-colors duration-150 ${
                  isActive
                    ? 'text-[#111214]'
                    : 'text-[#52545C] hover:text-[#111214]'
                }`}
              >
                {item.label}
                <span
                  aria-hidden="true"
                  className={`absolute inset-x-0 bottom-0 h-[1.5px] bg-[#111214] transition-transform duration-200 origin-center ${
                    isActive ? 'scale-x-100' : 'scale-x-0'
                  }`}
                />
              </a>
            );
          })}
        </nav>

        {/* Zone 3: Primary Subtle Action (GitHub) & Mobile Menu Button */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href={EXTERNAL_LINKS.github}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:inline-flex items-center gap-1.5 rounded-full border border-black/[0.1] bg-white/90 px-4 py-2 text-[13px] font-medium text-[#111214] whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[#111214] hover:text-white hover:border-[#111214]"
          >
            <span>GitHub</span>
            <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
          </a>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-controls="mobile-nav-panel"
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="md:hidden inline-flex h-11 w-11 items-center justify-center rounded-lg text-[#111214] transition-colors hover:bg-black/[0.05]"
          >
            {mobileOpen ? (
              <X className="h-5 w-5" aria-hidden="true" />
            ) : (
              <Menu className="h-5 w-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Panel */}
      {mobileOpen && (
        <div
          id="mobile-nav-panel"
          className="md:hidden border-t border-black/[0.06] bg-white/95 backdrop-blur-xl px-6 py-4"
        >
          <nav aria-label="Mobile navigation" className="flex flex-col gap-1">
            {NAV_ITEMS.map((item) => {
              const isActive = route === item.route;
              return (
                <a
                  key={item.route}
                  href={`#${item.route}`}
                  onClick={(e) => {
                    e.preventDefault();
                    handleLinkClick(item.route);
                  }}
                  aria-current={isActive ? 'page' : undefined}
                  className={`flex min-h-[44px] items-center justify-between rounded-lg px-3 text-[15px] font-medium transition-colors ${
                    isActive
                      ? 'bg-black/[0.04] text-[#111214]'
                      : 'text-[#52545C] hover:bg-black/[0.03] hover:text-[#111214]'
                  }`}
                >
                  <span>{item.label}</span>
                  {isActive && (
                    <span className="text-xs text-[#767982]">Current</span>
                  )}
                </a>
              );
            })}
            <div className="mt-2 pt-3 border-t border-black/[0.06] flex items-center gap-4 px-3">
              <a
                href={EXTERNAL_LINKS.github}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[44px] items-center gap-1.5 text-[14px] font-medium text-[#111214]"
              >
                <span>GitHub</span>
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>
              <a
                href={EXTERNAL_LINKS.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[44px] items-center gap-1.5 text-[14px] font-medium text-[#52545C] hover:text-[#111214]"
              >
                <span>YouTube</span>
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
