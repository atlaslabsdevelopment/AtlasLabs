import {ArrowUpRight} from 'lucide-react';
import {BRAND_ASSETS, EXTERNAL_LINKS} from '../lib/assets';
import type {AppRoute} from '../lib/router';
import {OptimizedImage} from './OptimizedImage';

interface FooterProps {
  onNavigate: (route: AppRoute) => void;
}

export function Footer({onNavigate}: FooterProps) {
  return (
    <footer className="border-t border-black/[0.08] bg-white">
      <div className="mx-auto max-w-6xl px-6 py-12 lg:px-8 lg:py-16">
        <div className="flex flex-col gap-10 md:flex-row md:items-start md:justify-between">
          <div className="space-y-3">
            <a
              href="#/"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/');
              }}
              className="inline-flex items-center gap-2.5 text-[#111214] transition-opacity hover:opacity-75"
            >
              <OptimizedImage
                asset={BRAND_ASSETS.mark}
                loading="lazy"
                imgClassName="h-5 w-5 object-contain"
              />
              <span className="font-display text-[15px] font-semibold tracking-tight">
                Atlas Labs
              </span>
            </a>
            <p className="text-[14px] text-[#52545C]">Made Enjoyable</p>
          </div>

          <div className="grid grid-cols-2 gap-10 sm:flex sm:gap-16">
            <div>
              <p className="text-[12px] font-medium text-[#767982] mb-3">
                Explore
              </p>
              <ul className="space-y-2.5 text-[14px]">
                <li>
                  <a
                    href="#/"
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigate('/');
                    }}
                    className="text-[#111214] hover:text-[#52545C] transition-colors"
                  >
                    Home
                  </a>
                </li>
                <li>
                  <a
                    href="#/atlasos"
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigate('/atlasos');
                    }}
                    className="text-[#111214] hover:text-[#52545C] transition-colors"
                  >
                    AtlasOS
                  </a>
                </li>
                <li>
                  <a
                    href="#/about"
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigate('/about');
                    }}
                    className="text-[#111214] hover:text-[#52545C] transition-colors"
                  >
                    About
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <p className="text-[12px] font-medium text-[#767982] mb-3">
                Connect
              </p>
              <ul className="space-y-2.5 text-[14px]">
                <li>
                  <a
                    href={EXTERNAL_LINKS.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[#111214] hover:text-[#52545C] transition-colors"
                  >
                    <span>GitHub</span>
                    <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                  </a>
                </li>
                <li>
                  <a
                    href={EXTERNAL_LINKS.youtube}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[#111214] hover:text-[#52545C] transition-colors"
                  >
                    <span>YouTube</span>
                    <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                  </a>
                </li>
                <li>
                  <a
                    href={`mailto:${EXTERNAL_LINKS.email}`}
                    className="text-[#111214] hover:text-[#52545C] transition-colors break-all"
                  >
                    {EXTERNAL_LINKS.email}
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-black/[0.06] flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between text-[13px] text-[#767982]">
          <p>© {new Date().getFullYear()} Atlas Labs</p>
          <p>Independent personal computing</p>
        </div>
      </div>
    </footer>
  );
}
