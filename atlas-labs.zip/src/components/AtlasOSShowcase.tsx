import {useEffect, useRef, useState} from 'react';
import gsap from 'gsap';
import {Maximize2, X} from 'lucide-react';
import {
  ATLAS_OS_SCREENS,
  type AtlasOSScreenKey,
} from '../lib/assets';
import {OptimizedImage} from './OptimizedImage';

interface AnnotationItem {
  id: string;
  screen: AtlasOSScreenKey;
  title: string;
  description: string;
  regionClass: string;
}

const ANNOTATIONS: AnnotationItem[] = [
  {
    id: 'topbar',
    screen: 'desktop',
    title: 'Top Bar & Active Context',
    description:
      'A minimal top edge anchors the system label on the left and active context in a centered surface.',
    regionClass: 'top-[2.2%] left-[1%] right-[1%] h-[6.5%]',
  },
  {
    id: 'appearance',
    screen: 'appearance',
    title: 'Appearance & Frosted Materials',
    description:
      'Preferences pair a live workspace preview with straightforward choices for Light or Dark mode, frosted materials, typography, and Day or Night surfaces.',
    regionClass: 'top-[26%] left-[25%] right-[25%] bottom-[22%]',
  },
  {
    id: 'dock',
    screen: 'desktop',
    title: 'Floating Dock & Quiet Time',
    description:
      'Core utilities rest in a centered translucent dock while date and time stay tucked cleanly into the lower-right corner.',
    regionClass: 'bottom-[0.8%] left-[37%] right-[1%] h-[8.5%]',
  },
];

interface AtlasOSShowcaseProps {
  enableAnnotations?: boolean;
  onLearnMore?: () => void;
}

export function AtlasOSShowcase({
  enableAnnotations = false,
  onLearnMore,
}: AtlasOSShowcaseProps) {
  const [activeScreen, setActiveScreen] = useState<AtlasOSScreenKey>('desktop');
  const [activeAnnotationId, setActiveAnnotationId] = useState<string | null>(null);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  const stageRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const isPointerFine = window.matchMedia('(pointer: fine)').matches;
    if (reducedMotion || !isPointerFine || !stageRef.current || !frameRef.current) {
      return;
    }

    const stage = stageRef.current;
    const frame = frameRef.current;

    const rotateXTo = gsap.quickTo(frame, 'rotateX', {duration: 0.45, ease: 'power3.out'});
    const rotateYTo = gsap.quickTo(frame, 'rotateY', {duration: 0.45, ease: 'power3.out'});

    const handleMove = (e: PointerEvent) => {
      const rect = stage.getBoundingClientRect();
      const relX = (e.clientX - rect.left) / rect.width - 0.5;
      const relY = (e.clientY - rect.top) / rect.height - 0.5;
      rotateYTo(relX * 2.4);
      rotateXTo(-relY * 2.0);
    };

    const handleLeave = () => {
      rotateXTo(0);
      rotateYTo(0);
    };

    stage.addEventListener('pointermove', handleMove);
    stage.addEventListener('pointerleave', handleLeave);
    return () => {
      stage.removeEventListener('pointermove', handleMove);
      stage.removeEventListener('pointerleave', handleLeave);
      gsap.set(frame, {rotateX: 0, rotateY: 0});
    };
  }, []);

  useEffect(() => {
    if (!lightboxOpen) {
      return;
    }
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setLightboxOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxOpen]);

  const currentAsset = ATLAS_OS_SCREENS[activeScreen];
  const activeAnnotation = ANNOTATIONS.find((a) => a.id === activeAnnotationId) || null;

  const handleSelectScreen = (key: AtlasOSScreenKey) => {
    setActiveScreen(key);
    setActiveAnnotationId(null);
  };

  const handleSelectAnnotation = (item: AnnotationItem) => {
    if (activeAnnotationId === item.id) {
      setActiveAnnotationId(null);
      return;
    }
    setActiveScreen(item.screen);
    setActiveAnnotationId(item.id);
  };

  return (
    <div className="w-full">
      {/* Control Strip */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div
          role="tablist"
          aria-label="AtlasOS interface views"
          className="inline-flex items-center rounded-xl bg-[#EFEFF2] p-1"
        >
          {(Object.keys(ATLAS_OS_SCREENS) as AtlasOSScreenKey[]).map((key) => {
            const screen = ATLAS_OS_SCREENS[key];
            const selected = activeScreen === key;
            return (
              <button
                key={key}
                type="button"
                role="tab"
                aria-selected={selected}
                onClick={() => handleSelectScreen(key)}
                className={`min-h-[38px] rounded-[9px] px-4 py-1.5 text-[13px] font-medium whitespace-nowrap shrink-0 transition-all duration-150 ${
                  selected
                    ? 'bg-white text-[#111214] shadow-[0_1px_3px_rgba(17,18,20,0.08)]'
                    : 'text-[#52545C] hover:text-[#111214]'
                }`}
              >
                {screen.label}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setLightboxOpen(true)}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-black/[0.08] bg-white px-3.5 py-2 text-[13px] font-medium text-[#111214] whitespace-nowrap shrink-0 transition-colors hover:bg-[#F6F6F8]"
          >
            <Maximize2 className="h-3.5 w-3.5 text-[#52545C]" aria-hidden="true" />
            <span>Inspect full size</span>
          </button>
        </div>
      </div>

      {/* Display Bezel Stage */}
      <div
        ref={stageRef}
        className="relative mx-auto w-full"
        style={{perspective: '1600px'}}
      >
        <div
          ref={frameRef}
          className="relative overflow-hidden rounded-[18px] sm:rounded-[26px] bg-[#111214] p-2 sm:p-3.5 shadow-[0_30px_80px_-24px_rgba(17,18,20,0.26)] ring-1 ring-black/15 will-change-transform"
        >
          <div className="relative aspect-[3420/2224] w-full overflow-hidden rounded-[12px] sm:rounded-[16px] bg-[#0B0C0E]">
            {(Object.keys(ATLAS_OS_SCREENS) as AtlasOSScreenKey[]).map((key) => {
              const screen = ATLAS_OS_SCREENS[key];
              const isVisible = activeScreen === key;
              return (
                <div
                  key={key}
                  aria-hidden={!isVisible}
                  className={`absolute inset-0 transition-[opacity,transform] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${
                    isVisible
                      ? 'opacity-100 scale-100 z-10'
                      : 'opacity-0 scale-[1.012] z-0 pointer-events-none'
                  }`}
                >
                  <OptimizedImage
                    asset={screen}
                    loading={key === 'desktop' ? 'eager' : 'lazy'}
                    fetchPriority={key === 'desktop' ? 'high' : 'auto'}
                    imgClassName="h-full w-full object-cover select-none"
                  />
                </div>
              );
            })}

            {/* Optional subtle focus highlight when an observation note is selected */}
            {enableAnnotations && activeAnnotation && activeAnnotation.screen === activeScreen && (
              <div
                aria-hidden="true"
                className={`pointer-events-none absolute z-20 rounded-xl border-2 border-white/90 shadow-[0_0_0_9999px_rgba(17,18,20,0.34)] transition-all duration-300 ${activeAnnotation.regionClass}`}
              />
            )}
          </div>
        </div>
      </div>

      {/* Caption Row */}
      <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-[14px] leading-relaxed text-[#52545C] max-w-2xl">
          {currentAsset.caption}
        </p>
        {onLearnMore && (
          <button
            type="button"
            onClick={onLearnMore}
            className="inline-flex min-h-[40px] items-center gap-1.5 self-start sm:self-auto text-[14px] font-medium text-[#111214] whitespace-nowrap shrink-0 underline decoration-black/20 underline-offset-4 transition-colors hover:decoration-[#111214]"
          >
            View AtlasOS preview
          </button>
        )}
      </div>

      {/* Interactive Interface Observation Notes (AtlasOS Page) */}
      {enableAnnotations && (
        <div className="mt-10 border-t border-black/[0.08] pt-8">
          <div className="mb-4 flex items-center justify-between gap-4">
            <h3 className="font-display text-[14px] font-semibold tracking-tight text-[#111214]">
              Interface highlights
            </h3>
            {activeAnnotation && (
              <button
                type="button"
                onClick={() => setActiveAnnotationId(null)}
                className="text-[13px] font-medium text-[#52545C] hover:text-[#111214] transition-colors"
              >
                Clear highlight
              </button>
            )}
          </div>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            {ANNOTATIONS.map((item) => {
              const selected = activeAnnotationId === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleSelectAnnotation(item)}
                  aria-pressed={selected}
                  className={`text-left rounded-2xl border p-5 transition-all duration-150 ${
                    selected
                      ? 'border-[#111214] bg-[#F6F6F8]'
                      : 'border-black/[0.08] bg-white hover:border-black/20 hover:bg-[#FAFAFB]'
                  }`}
                >
                  <div className="text-[12px] font-medium text-[#767982] mb-1.5">
                    {ATLAS_OS_SCREENS[item.screen].label}
                  </div>
                  <div className="font-display text-[15px] font-semibold text-[#111214] mb-1.5">
                    {item.title}
                  </div>
                  <p className="text-[14px] leading-relaxed text-[#52545C]">
                    {item.description}
                  </p>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Fullscreen Lightbox */}
      {lightboxOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={`${currentAsset.label} full-size inspection`}
          className="fixed inset-0 z-50 flex flex-col bg-[#0B0C0E]/95 backdrop-blur-md p-4 sm:p-8"
          onClick={() => setLightboxOpen(false)}
        >
          <div
            className="mx-auto flex w-full max-w-7xl items-center justify-between gap-4 pb-4 text-white"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <span className="font-display text-[15px] font-semibold">
                AtlasOS — {currentAsset.label}
              </span>
              <span className="hidden sm:inline text-[13px] text-white/60">
                Early development screenshot
              </span>
            </div>
            <div className="flex items-center gap-2">
              {(Object.keys(ATLAS_OS_SCREENS) as AtlasOSScreenKey[]).map((key) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setActiveScreen(key)}
                  className={`min-h-[38px] rounded-lg px-3 py-1.5 text-[13px] font-medium whitespace-nowrap transition-colors ${
                    activeScreen === key
                      ? 'bg-white text-[#111214]'
                      : 'bg-white/10 text-white/80 hover:bg-white/20'
                  }`}
                >
                  {ATLAS_OS_SCREENS[key].label}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setLightboxOpen(false)}
                aria-label="Close inspection view"
                className="ml-2 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-white/10 text-white transition-colors hover:bg-white/20"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>
          </div>

          <div
            className="mx-auto flex min-h-0 flex-1 w-full max-w-7xl items-center justify-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="max-h-full w-full overflow-hidden rounded-2xl ring-1 ring-white/15 bg-black">
              <OptimizedImage
                asset={currentAsset}
                loading="eager"
                imgClassName="max-h-[82vh] w-full object-contain mx-auto"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
