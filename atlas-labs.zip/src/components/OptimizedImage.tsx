import {useState} from 'react';
import type {MediaAsset} from '../lib/assets';

interface OptimizedImageProps {
  asset: MediaAsset;
  className?: string;
  imgClassName?: string;
  loading?: 'eager' | 'lazy';
  decoding?: 'sync' | 'async' | 'auto';
  fetchPriority?: 'high' | 'low' | 'auto';
}

export function OptimizedImage({
  asset,
  className = '',
  imgClassName = '',
  loading = 'eager',
  decoding = 'async',
  fetchPriority = 'auto',
}: OptimizedImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        className={`flex items-center justify-center bg-neutral-100 text-neutral-500 text-sm px-6 py-10 text-center ${className}`}
        role="img"
        aria-label={asset.alt}
      >
        <span className="max-w-md">{asset.alt}</span>
      </div>
    );
  }

  return (
    <picture className={className}>
      <source srcSet={asset.webp} type="image/webp" />
      <img
        src={asset.fallback}
        alt={asset.alt}
        width={asset.width}
        height={asset.height}
        loading={loading}
        decoding={decoding}
        fetchPriority={fetchPriority}
        referrerPolicy="no-referrer"
        onError={() => setHasError(true)}
        className={imgClassName}
      />
    </picture>
  );
}
